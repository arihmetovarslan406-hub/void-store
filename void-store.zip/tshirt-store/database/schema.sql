-- ============================================================
-- T-SHIRT STORE DATABASE SCHEMA
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Categories
CREATE TABLE categories (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(100) NOT NULL,
  slug VARCHAR(100) UNIQUE NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Products
CREATE TABLE products (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(255) NOT NULL,
  slug VARCHAR(255) UNIQUE NOT NULL,
  description TEXT,
  price DECIMAL(12, 2) NOT NULL,
  category_id UUID REFERENCES categories(id),
  sizes TEXT[] DEFAULT '{}',
  is_active BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Product Images
CREATE TABLE product_images (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  url TEXT NOT NULL,
  is_primary BOOLEAN DEFAULT FALSE,
  sort_order INT DEFAULT 0,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Orders
CREATE TABLE orders (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_number SERIAL UNIQUE,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  phone VARCHAR(30) NOT NULL,
  telegram_username VARCHAR(100),
  telegram_user_id BIGINT,
  address TEXT NOT NULL,
  comment TEXT,
  total_amount DECIMAL(12, 2) NOT NULL,
  status VARCHAR(30) DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Order Items
CREATE TABLE order_items (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES products(id),
  product_name VARCHAR(255) NOT NULL,
  size VARCHAR(10) NOT NULL,
  quantity INT NOT NULL,
  price DECIMAL(12, 2) NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Admin Users
CREATE TABLE admin_users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  username VARCHAR(100) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_products_is_active ON products(is_active);
CREATE INDEX idx_order_items_order ON order_items(order_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_created ON orders(created_at DESC);
CREATE INDEX idx_product_images_product ON product_images(product_id);

-- Triggers
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER products_updated_at BEFORE UPDATE ON products
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER orders_updated_at BEFORE UPDATE ON orders
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- ============================================================
-- SEED DATA
-- ============================================================

INSERT INTO categories (name, slug) VALUES
  ('Oversized', 'oversized'),
  ('Basic', 'basic'),
  ('Graphic', 'graphic'),
  ('Limited', 'limited');

INSERT INTO products (name, slug, description, price, sizes, category_id) VALUES
  (
    'BLACK OVERSIZED TEE',
    'black-oversized-tee',
    'Premium heavyweight cotton oversized fit. 320gsm fabric. Dropped shoulders. Boxy silhouette. The foundation of any wardrobe.',
    180000,
    ARRAY['XS','S','M','L','XL','XXL'],
    (SELECT id FROM categories WHERE slug = 'oversized')
  ),
  (
    'WHITE BASIC TEE',
    'white-basic-tee',
    'Essential white tee. 240gsm combed cotton. Clean cut. Perfect fit. Wear it alone or layer it.',
    150000,
    ARRAY['XS','S','M','L','XL','XXL'],
    (SELECT id FROM categories WHERE slug = 'basic')
  ),
  (
    'VOID GRAPHIC TEE',
    'void-graphic-tee',
    'Screen printed heavyweight tee. Original artwork. Limited run. 300gsm cotton. Washed for that broken-in feel.',
    220000,
    ARRAY['S','M','L','XL'],
    (SELECT id FROM categories WHERE slug = 'graphic')
  ),
  (
    'ARCHIVE LOGO TEE',
    'archive-logo-tee',
    'Embroidered chest logo. Heavyweight cotton. Relaxed fit. This one speaks without shouting.',
    200000,
    ARRAY['XS','S','M','L','XL','XXL'],
    (SELECT id FROM categories WHERE slug = 'basic')
  ),
  (
    'DISTRESSED VINTAGE TEE',
    'distressed-vintage-tee',
    'Pre-distressed finish. Vintage wash. Oversized silhouette. Every piece ages differently.',
    250000,
    ARRAY['S','M','L','XL'],
    (SELECT id FROM categories WHERE slug = 'limited')
  ),
  (
    'MONOCHROME ESSENTIAL',
    'monochrome-essential',
    'Seamless construction. No side seams. Drop shoulder. The purist choice.',
    170000,
    ARRAY['XS','S','M','L','XL','XXL'],
    (SELECT id FROM categories WHERE slug = 'basic')
  );

-- Product images (using placeholder images)
INSERT INTO product_images (product_id, url, is_primary, sort_order) VALUES
  ((SELECT id FROM products WHERE slug = 'black-oversized-tee'), 'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?w=800', true, 0),
  ((SELECT id FROM products WHERE slug = 'black-oversized-tee'), 'https://images.unsplash.com/photo-1583743814966-8936f5b7be1a?w=800', false, 1),
  ((SELECT id FROM products WHERE slug = 'white-basic-tee'), 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=800', true, 0),
  ((SELECT id FROM products WHERE slug = 'white-basic-tee'), 'https://images.unsplash.com/photo-1503341504253-dff4815485f1?w=800', false, 1),
  ((SELECT id FROM products WHERE slug = 'void-graphic-tee'), 'https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=800', true, 0),
  ((SELECT id FROM products WHERE slug = 'archive-logo-tee'), 'https://images.unsplash.com/photo-1622445275576-721325763afe?w=800', true, 0),
  ((SELECT id FROM products WHERE slug = 'distressed-vintage-tee'), 'https://images.unsplash.com/photo-1529374255404-311a2a4f1fd9?w=800', true, 0),
  ((SELECT id FROM products WHERE slug = 'monochrome-essential'), 'https://images.unsplash.com/photo-1543076447-215ad9ba6923?w=800', true, 0);
