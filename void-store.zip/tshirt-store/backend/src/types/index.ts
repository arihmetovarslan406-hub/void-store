export interface Product {
  id: string;
  name: string;
  slug: string;
  description: string;
  price: number;
  category_id: string;
  sizes: string[];
  is_active: boolean;
  created_at: string;
  updated_at: string;
  images?: ProductImage[];
  category?: Category;
}

export interface ProductImage {
  id: string;
  product_id: string;
  url: string;
  is_primary: boolean;
  sort_order: number;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
}

export interface Order {
  id: string;
  order_number: number;
  first_name: string;
  last_name: string;
  phone: string;
  telegram_username?: string;
  telegram_user_id?: number;
  address: string;
  comment?: string;
  total_amount: number;
  status: OrderStatus;
  created_at: string;
  updated_at: string;
  items?: OrderItem[];
}

export type OrderStatus =
  | 'pending'
  | 'confirmed'
  | 'processing'
  | 'shipped'
  | 'delivered'
  | 'cancelled';

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string;
  product_name: string;
  size: string;
  quantity: number;
  price: number;
}

export interface CreateOrderRequest {
  first_name: string;
  last_name: string;
  phone: string;
  telegram_username?: string;
  telegram_user_id?: number;
  address: string;
  comment?: string;
  items: {
    product_id: string;
    size: string;
    quantity: number;
  }[];
}

export interface AdminUser {
  id: string;
  username: string;
  created_at: string;
}

export interface JWTPayload {
  id: string;
  username: string;
}

declare global {
  namespace Express {
    interface Request {
      admin?: JWTPayload;
    }
  }
}
