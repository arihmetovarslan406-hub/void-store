import TelegramBot from 'node-telegram-bot-api';
import { Order } from '../types';

let bot: TelegramBot | null = null;

export const initBot = (): TelegramBot | null => {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  if (!token) {
    console.warn('[Bot] TELEGRAM_BOT_TOKEN not set — bot disabled');
    return null;
  }
  try {
    bot = new TelegramBot(token, { polling: false });
    console.log('[Bot] Telegram bot initialized');
    return bot;
  } catch (err) {
    console.error('[Bot] Failed to initialize:', err);
    return null;
  }
};

export const formatPrice = (price: number): string => {
  return new Intl.NumberFormat('uz-UZ').format(price) + ' сум';
};

export const sendOrderNotification = async (order: Order): Promise<void> => {
  const chatId = process.env.TELEGRAM_ADMIN_CHAT_ID;
  if (!bot || !chatId) {
    console.warn('[Bot] Cannot send notification — bot or chatId missing');
    return;
  }

  const items = (order.items || [])
    .map(item => `  • ${item.product_name} [${item.size}] × ${item.quantity}`)
    .join('\n');

  const message = [
    `🛍 *НОВЫЙ ЗАКАЗ #${order.order_number}*`,
    ``,
    `👤 *Клиент:*`,
    `  Имя: ${order.first_name} ${order.last_name}`,
    `  Телефон: ${order.phone}`,
    order.telegram_username ? `  Telegram: @${order.telegram_username}` : null,
    ``,
    `📦 *Товары:*`,
    items,
    ``,
    `💰 *Итого: ${formatPrice(order.total_amount)}*`,
    ``,
    `📍 *Адрес:*`,
    `  ${order.address}`,
    order.comment ? `\n💬 *Комментарий:*\n  ${order.comment}` : null,
    ``,
    `🕐 ${new Date(order.created_at).toLocaleString('ru-RU')}`,
  ]
    .filter(Boolean)
    .join('\n');

  try {
    await bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    console.log(`[Bot] Order #${order.order_number} notification sent`);
  } catch (err) {
    console.error('[Bot] Failed to send notification:', err);
  }
};

export const sendStatusUpdate = async (
  telegramUserId: number,
  orderNumber: number,
  status: string
): Promise<void> => {
  if (!bot) return;

  const statusMap: Record<string, string> = {
    confirmed: '✅ Подтверждён',
    processing: '⚙️ В обработке',
    shipped: '🚚 Отправлен',
    delivered: '📦 Доставлен',
    cancelled: '❌ Отменён',
  };

  const statusText = statusMap[status] || status;
  const message = `Статус вашего заказа *#${orderNumber}* обновлён: ${statusText}`;

  try {
    await bot.sendMessage(telegramUserId, message, { parse_mode: 'Markdown' });
  } catch (err) {
    console.error('[Bot] Failed to send status update:', err);
  }
};

export default bot;
