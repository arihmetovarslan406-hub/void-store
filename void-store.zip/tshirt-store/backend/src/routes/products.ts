import { Router, Request, Response } from 'express';
import multer from 'multer';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { query } from '../utils/db';
import { authMiddleware } from '../middleware/auth';

const router = Router();

// Multer storage config
const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, process.env.UPLOAD_DIR || 'uploads');
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname);
    cb(null, `${uuidv4()}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: { fileSize: Number(process.env.MAX_FILE_SIZE) || 5 * 1024 * 1024 },
  fileFilter: (_req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp'];
    if (allowed.includes(file.mimetype)) cb(null, true);
    else cb(new Error('Only JPEG, PNG, WebP images are allowed'));
  },
});

// ──────────────────────────────────────────────────────────────
// PUBLIC ROUTES
// ──────────────────────────────────────────────────────────────

// GET /api/products — list all active products
router.get('/', async (_req: Request, res: Response) => {
  try {
    const { rows: products } = await query(`
      SELECT
        p.*,
        c.name  AS category_name,
        c.slug  AS category_slug,
        (
          SELECT json_agg(pi ORDER BY pi.sort_order)
          FROM product_images pi
          WHERE pi.product_id = p.id
        ) AS images
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE p.is_active = TRUE
      ORDER BY p.created_at DESC
    `);
    res.json(products);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// GET /api/products/categories
router.get('/categories', async (_req: Request, res: Response) => {
  try {
    const { rows } = await query('SELECT * FROM categories ORDER BY name');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// GET /api/products/:slug
router.get('/:slug', async (req: Request, res: Response) => {
  try {
    const { rows } = await query(`
      SELECT
        p.*,
        c.name  AS category_name,
        c.slug  AS category_slug,
        (
          SELECT json_agg(pi ORDER BY pi.sort_order)
          FROM product_images pi
          WHERE pi.product_id = p.id
        ) AS images
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE p.slug = $1
    `, [req.params.slug]);

    if (!rows[0]) {
      res.status(404).json({ error: 'Product not found' });
      return;
    }
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ──────────────────────────────────────────────────────────────
// ADMIN ROUTES (protected)
// ──────────────────────────────────────────────────────────────

// GET /api/products/admin/all
router.get('/admin/all', authMiddleware, async (_req: Request, res: Response) => {
  try {
    const { rows } = await query(`
      SELECT p.*, c.name AS category_name,
        (SELECT json_agg(pi ORDER BY pi.sort_order) FROM product_images pi WHERE pi.product_id = p.id) AS images
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      ORDER BY p.created_at DESC
    `);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /api/products — create product
router.post('/', authMiddleware, async (req: Request, res: Response) => {
  const { name, description, price, category_id, sizes } = req.body;
  if (!name || !price) {
    res.status(400).json({ error: 'name and price are required' });
    return;
  }

  const slug = name.toLowerCase().replace(/\s+/g, '-').replace(/[^a-z0-9-]/g, '');

  try {
    const { rows } = await query(
      `INSERT INTO products (name, slug, description, price, category_id, sizes)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [name, slug, description, price, category_id, sizes || []]
    );
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// PATCH /api/products/:id — update product
router.patch('/:id', authMiddleware, async (req: Request, res: Response) => {
  const { name, description, price, category_id, sizes, is_active } = req.body;
  try {
    const { rows } = await query(
      `UPDATE products SET
        name        = COALESCE($1, name),
        description = COALESCE($2, description),
        price       = COALESCE($3, price),
        category_id = COALESCE($4, category_id),
        sizes       = COALESCE($5, sizes),
        is_active   = COALESCE($6, is_active)
       WHERE id = $7 RETURNING *`,
      [name, description, price, category_id, sizes, is_active, req.params.id]
    );
    if (!rows[0]) {
      res.status(404).json({ error: 'Product not found' });
      return;
    }
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// DELETE /api/products/:id
router.delete('/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    await query('DELETE FROM products WHERE id = $1', [req.params.id]);
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// POST /api/products/:id/images
router.post('/:id/images', authMiddleware, upload.array('images', 5), async (req: Request, res: Response) => {
  const files = req.files as Express.Multer.File[];
  if (!files?.length) {
    res.status(400).json({ error: 'No files uploaded' });
    return;
  }

  try {
    const baseUrl = `${req.protocol}://${req.get('host')}`;
    const insertions = files.map((f, i) =>
      query(
        `INSERT INTO product_images (product_id, url, sort_order) VALUES ($1, $2, $3) RETURNING *`,
        [req.params.id, `${baseUrl}/uploads/${f.filename}`, i]
      )
    );
    const results = await Promise.all(insertions);
    res.status(201).json(results.map(r => r.rows[0]));
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
