import { Router, Request, Response } from 'express';
import { query, getClient } from '../utils/db';
import { authMiddleware } from '../middleware/auth';
import { sendOrderNotification } from '../utils/telegram';
import { CreateOrderRequest } from '../types';

const router = Router();

// ──────────────────────────────────────────────────────────────
// PUBLIC ROUTES
// ──────────────────────────────────────────────────────────────

// POST /api/orders — create a new order
router.post('/', async (req: Request, res: Response) => {
  const {
    first_name, last_name, phone,
    telegram_username, telegram_user_id,
    address, comment, items,
  } = req.body as CreateOrderRequest;

  if (!first_name || !last_name || !phone || !address || !items?.length) {
    res.status(400).json({ error: 'Missing required fields' });
    return;
  }

  const client = await getClient();
  try {
    await client.query('BEGIN');

    // Fetch products and calculate total
    const productIds = items.map(i => i.product_id);
    const { rows: products } = await client.query(
      'SELECT id, name, price FROM products WHERE id = ANY($1)',
      [productIds]
    );

    const productMap = new Map(products.map(p => [p.id, p]));

    let totalAmount = 0;
    const enrichedItems = items.map(item => {
      const product = productMap.get(item.product_id);
      if (!product) throw new Error(`Product ${item.product_id} not found`);
      const lineTotal = Number(product.price) * item.quantity;
      totalAmount += lineTotal;
      return { ...item, product_name: product.name, price: product.price };
    });

    // Insert order
    const { rows: [order] } = await client.query(
      `INSERT INTO orders
         (first_name, last_name, phone, telegram_username, telegram_user_id, address, comment, total_amount)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
       RETURNING *`,
      [first_name, last_name, phone, telegram_username, telegram_user_id, address, comment, totalAmount]
    );

    // Insert order items
    for (const item of enrichedItems) {
      await client.query(
        `INSERT INTO order_items (order_id, product_id, product_name, size, quantity, price)
         VALUES ($1,$2,$3,$4,$5,$6)`,
        [order.id, item.product_id, item.product_name, item.size, item.quantity, item.price]
      );
    }

    await client.query('COMMIT');

    // Fetch full order for notification
    const { rows: [fullOrder] } = await query(
      `SELECT o.*,
         (SELECT json_agg(oi) FROM order_items oi WHERE oi.order_id = o.id) AS items
       FROM orders o WHERE o.id = $1`,
      [order.id]
    );

    // Send Telegram notification (non-blocking)
    sendOrderNotification(fullOrder).catch(console.error);

    res.status(201).json({ order_number: order.order_number, id: order.id });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error(err);
    res.status(500).json({ error: 'Failed to create order' });
  } finally {
    client.release();
  }
});

// ──────────────────────────────────────────────────────────────
// ADMIN ROUTES
// ──────────────────────────────────────────────────────────────

// GET /api/orders — list all orders
router.get('/', authMiddleware, async (req: Request, res: Response) => {
  const { status, page = '1', limit = '20' } = req.query;
  const offset = (Number(page) - 1) * Number(limit);

  const conditions: string[] = [];
  const params: unknown[] = [];

  if (status) {
    params.push(status);
    conditions.push(`o.status = $${params.length}`);
  }

  const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

  try {
    const { rows } = await query(
      `SELECT o.*,
         (SELECT json_agg(oi ORDER BY oi.created_at) FROM order_items oi WHERE oi.order_id = o.id) AS items
       FROM orders o
       ${where}
       ORDER BY o.created_at DESC
       LIMIT $${params.length + 1} OFFSET $${params.length + 2}`,
      [...params, Number(limit), offset]
    );

    const { rows: [{ count }] } = await query(
      `SELECT COUNT(*) FROM orders o ${where}`,
      params
    );

    res.json({ orders: rows, total: Number(count) });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// GET /api/orders/:id
router.get('/:id', authMiddleware, async (req: Request, res: Response) => {
  try {
    const { rows } = await query(
      `SELECT o.*,
         (SELECT json_agg(oi ORDER BY oi.created_at) FROM order_items oi WHERE oi.order_id = o.id) AS items
       FROM orders o WHERE o.id = $1`,
      [req.params.id]
    );
    if (!rows[0]) {
      res.status(404).json({ error: 'Order not found' });
      return;
    }
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// PATCH /api/orders/:id/status
router.patch('/:id/status', authMiddleware, async (req: Request, res: Response) => {
  const { status } = req.body;
  const validStatuses = ['pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'];

  if (!validStatuses.includes(status)) {
    res.status(400).json({ error: 'Invalid status' });
    return;
  }

  try {
    const { rows } = await query(
      'UPDATE orders SET status = $1 WHERE id = $2 RETURNING *',
      [status, req.params.id]
    );
    if (!rows[0]) {
      res.status(404).json({ error: 'Order not found' });
      return;
    }
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
