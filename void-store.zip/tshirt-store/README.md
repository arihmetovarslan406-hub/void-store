# VOID STORE — Telegram Mini App

> Premium streetwear store built as a Telegram Mini App.
> React + Vite + TypeScript · Node.js + Express · PostgreSQL · Telegram Bot API

---

## 📁 Структура проекта

```
void-tshirt-store/
├── frontend/                 # React + Vite + TypeScript
│   ├── src/
│   │   ├── components/
│   │   │   ├── layout/       # Header, nav
│   │   │   ├── product/      # ProductCard, SizeSelector
│   │   │   └── ui/           # QuantityPicker, Spinner
│   │   ├── hooks/
│   │   │   └── useTelegram.ts    # Telegram WebApp SDK hook
│   │   ├── pages/
│   │   │   ├── HomePage.tsx      # Каталог
│   │   │   ├── ProductPage.tsx   # Страница товара
│   │   │   ├── CartPage.tsx      # Корзина
│   │   │   ├── CheckoutPage.tsx  # Оформление заказа
│   │   │   └── AdminPage.tsx     # Админ панель
│   │   ├── store/
│   │   │   ├── cartStore.ts      # Zustand корзина (persist)
│   │   │   └── adminStore.ts     # Zustand авторизация
│   │   ├── types/index.ts        # TypeScript типы
│   │   └── utils/
│   │       ├── api.ts            # Axios API клиент
│   │       └── helpers.ts        # formatPrice, getImageUrl
├── backend/                  # Node.js + Express + TypeScript
│   ├── src/
│   │   ├── routes/
│   │   │   ├── products.ts       # CRUD товаров + загрузка фото
│   │   │   ├── orders.ts         # Создание и управление заказами
│   │   │   └── auth.ts           # JWT авторизация
│   │   ├── middleware/
│   │   │   └── auth.ts           # JWT middleware
│   │   └── utils/
│   │       ├── db.ts             # PostgreSQL pool
│   │       ├── telegram.ts       # Bot уведомления
│   │       └── setupAdmin.ts     # Создание admin пользователя
│   └── uploads/              # Загруженные фото
├── database/
│   └── schema.sql            # Схема БД + seed данные
└── README.md
```

---

## 🚀 Установка и запуск

### 1. Требования

- **Node.js** >= 18
- **PostgreSQL** >= 14 (или Supabase)
- **Telegram Bot Token** (от @BotFather)

### 2. Клонирование и установка зависимостей

```bash
# Клонировать репозиторий
git clone https://github.com/your-username/void-store.git
cd void-store

# Установить все зависимости
npm run install:all
```

### 3. Настройка базы данных

#### Вариант A — Локальный PostgreSQL:
```bash
# Создать базу данных
psql -U postgres -c "CREATE DATABASE tshirt_store;"

# Применить схему
psql -U postgres -d tshirt_store -f database/schema.sql
```

#### Вариант B — Supabase:
1. Создать проект на [supabase.com](https://supabase.com)
2. Зайти в **SQL Editor**
3. Вставить и выполнить содержимое `database/schema.sql`
4. Скопировать `DATABASE_URL` из Settings → Database → Connection string (URI mode)

### 4. Настройка окружения

#### Backend:
```bash
cp backend/.env.example backend/.env
```

Отредактировать `backend/.env`:
```env
PORT=4000
NODE_ENV=development

# PostgreSQL / Supabase
DATABASE_URL=postgresql://user:password@localhost:5432/tshirt_store

# JWT
JWT_SECRET=your-super-secret-jwt-key-minimum-32-chars

# Telegram Bot
TELEGRAM_BOT_TOKEN=1234567890:ABCdefGHIjklMNOpqrsTUVwxyz
TELEGRAM_ADMIN_CHAT_ID=123456789

# Admin
ADMIN_USERNAME=admin
ADMIN_PASSWORD=YourSecurePassword123!

# CORS
FRONTEND_URL=http://localhost:5173
```

#### Frontend:
```bash
cp frontend/.env.example frontend/.env
```

### 5. Создание admin пользователя

```bash
npm run setup:admin
```

### 6. Запуск в режиме разработки

```bash
# Запустить оба сервера одновременно
npm run dev

# Или по отдельности:
npm run dev:backend   # http://localhost:4000
npm run dev:frontend  # http://localhost:5173
```

---

## 🤖 Подключение Telegram Bot

### Шаг 1 — Создать бота

1. Открыть Telegram → найти [@BotFather](https://t.me/BotFather)
2. Отправить `/newbot`
3. Придумать имя: `Void Store Bot`
4. Придумать username: `voidstore_bot`
5. Скопировать **токен** → вставить в `TELEGRAM_BOT_TOKEN`

### Шаг 2 — Узнать свой Chat ID

```
1. Найти @userinfobot в Telegram
2. Отправить /start
3. Скопировать ваш ID → вставить в TELEGRAM_ADMIN_CHAT_ID
```

Или через API:
```bash
curl https://api.telegram.org/bot<YOUR_TOKEN>/getUpdates
```

### Шаг 3 — Настроить Mini App

1. В BotFather отправить `/newapp` (или `/mybots` → выбрать бота → Bot Settings → Menu Button)
2. Указать URL вашего задеплоенного фронтенда
3. Или для разработки использовать **ngrok**:
```bash
npx ngrok http 5173
# Скопировать https://xxxx.ngrok.io → вставить в BotFather
```

### Шаг 4 — Запустить Mini App

В BotFather:
```
/mybots → Ваш бот → Bot Settings → Menu Button → Edit Menu Button URL
Вставить: https://your-frontend-url.com
```

Или добавить кнопку в боте:
```
/setmenubutton → URL → https://your-frontend-url.com
```

---

## 🌐 Деплой в production

### Вариант A — Railway (рекомендован)

```bash
# 1. Установить Railway CLI
npm install -g @railway/cli

# 2. Логин
railway login

# 3. Создать проект
railway new

# 4. Добавить PostgreSQL
railway add postgresql

# 5. Задать переменные окружения
railway variables set TELEGRAM_BOT_TOKEN=... TELEGRAM_ADMIN_CHAT_ID=... JWT_SECRET=...

# 6. Деплой backend
cd backend && railway up

# 7. Деплой frontend (Vercel/Netlify или тоже Railway)
cd ../frontend && railway up
```

### Вариант B — VPS (Ubuntu)

```bash
# 1. Установить Node.js 20
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# 2. Установить PM2
npm install -g pm2

# 3. Собрать проект
npm run build:backend
npm run build:frontend

# 4. Запустить backend с PM2
cd backend && pm2 start dist/index.js --name void-api

# 5. Сервировать frontend через nginx
# Скопировать frontend/dist → /var/www/void-store
sudo cp -r frontend/dist /var/www/void-store

# 6. Настроить nginx (см. ниже)
```

#### Nginx конфигурация:
```nginx
server {
    listen 80;
    server_name yourdomain.com;

    # Frontend
    location / {
        root /var/www/void-store;
        try_files $uri $uri/ /index.html;
    }

    # Backend API proxy
    location /api {
        proxy_pass http://localhost:4000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    # Uploads
    location /uploads {
        proxy_pass http://localhost:4000;
    }
}
```

### Вариант C — Vercel (Frontend) + Railway (Backend)

```bash
# Frontend → Vercel
cd frontend
npx vercel deploy --prod
# Задать VITE_API_URL=https://your-backend.railway.app/api

# Backend → Railway
cd ../backend
railway up
```

---

## 🔑 Доступ к Admin Panel

После деплоя открыть:
```
https://your-store.com/admin
```

Логин/пароль — из `.env`:
```
ADMIN_USERNAME=admin
ADMIN_PASSWORD=...
```

---

## 📱 Страницы приложения

| Путь | Описание |
|------|----------|
| `/` | Каталог товаров |
| `/product/:slug` | Страница товара |
| `/cart` | Корзина |
| `/checkout` | Оформление заказа |
| `/admin` | Панель администратора |

---

## 🛠 API Endpoints

### Публичные
| Method | Path | Description |
|--------|------|-------------|
| GET | `/api/products` | Список товаров |
| GET | `/api/products/:slug` | Товар по slug |
| GET | `/api/products/categories` | Категории |
| POST | `/api/orders` | Создать заказ |

### Защищённые (Bearer JWT)
| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/auth/login` | Авторизация |
| GET | `/api/orders` | Список заказов |
| PATCH | `/api/orders/:id/status` | Изменить статус |
| GET | `/api/products/admin/all` | Все товары (включая скрытые) |
| POST | `/api/products` | Создать товар |
| PATCH | `/api/products/:id` | Обновить товар |
| DELETE | `/api/products/:id` | Удалить товар |
| POST | `/api/products/:id/images` | Загрузить фото |

---

## 🎨 Дизайн

- **Стиль**: Streetwear минимализм (Corteiz, Represent, Fear Of God)
- **Тема**: Dark mode (черный #0A0A0A / белый #F5F5F0)
- **Шрифты**: Bebas Neue (заголовки) + DM Sans (тело) + JetBrains Mono (UI метки)
- **Анимации**: Framer Motion — page transitions, hover effects, cart badge
- **Mobile-first**: Оптимизирован под Telegram WebApp

---

## 📦 Tech Stack

| Layer | Tech |
|-------|------|
| Frontend | React 18, Vite, TypeScript, TailwindCSS |
| State | Zustand (cart + auth, persist) |
| Forms | React Hook Form + Zod |
| Animation | Framer Motion |
| Backend | Node.js, Express, TypeScript |
| Database | PostgreSQL (pg pool) |
| Auth | JWT (jsonwebtoken + bcrypt) |
| File upload | Multer |
| Bot | node-telegram-bot-api |
| Telegram | WebApp SDK |

---

## ⚠️ Важные замечания

1. **HTTPS обязателен** для Telegram Mini App в production
2. **CORS** — обновите `FRONTEND_URL` в backend `.env`
3. **Images** — в production используйте S3/Cloudflare R2 вместо локальных uploads
4. **JWT_SECRET** — минимум 32 символа, используйте random generator
5. **Supabase** — не забудьте включить SSL (`?sslmode=require` в DATABASE_URL)

---

*Built with ❤️ for the culture*
