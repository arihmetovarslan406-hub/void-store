import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Package, ShoppingBag, LogOut, Plus, Edit2, Trash2,
  ChevronDown, Upload, X, Check, RefreshCw
} from 'lucide-react';
import {
  fetchOrders, updateOrderStatus,
  adminFetchProducts, createProduct, updateProduct, deleteProduct, uploadProductImages
} from '../utils/api';
import { useAdminStore } from '../store/adminStore';
import { Order, Product, OrderStatus } from '../types';
import { formatPrice } from '../utils/helpers';

// ─── Login ───────────────────────────────────────────────────
const AdminLogin = () => {
  const login = useAdminStore(s => s.login);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    setLoading(true);
    setError('');
    try {
      await login(username, password);
    } catch {
      setError('Неверные данные');
      hapticError();
    } finally {
      setLoading(false);
    }
  };

  const hapticError = () => window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred('error');

  return (
    <div className="min-h-screen flex items-center justify-center bg-brand-black px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="w-full max-w-sm"
      >
        <h1 className="display-text text-5xl text-brand-white mb-2">ADMIN</h1>
        <p className="section-tag mb-8">VOID STORE PANEL</p>

        <div className="space-y-3">
          <input
            value={username}
            onChange={e => setUsername(e.target.value)}
            placeholder="Логин"
            className="input-field"
          />
          <input
            value={password}
            onChange={e => setPassword(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleLogin()}
            placeholder="Пароль"
            type="password"
            className="input-field"
          />
          {error && <p className="font-mono text-xs text-red-400">{error}</p>}
          <button
            onClick={handleLogin}
            disabled={loading}
            className="btn-primary w-full tracking-widest"
          >
            {loading ? 'ВХОД...' : 'ВОЙТИ'}
          </button>
        </div>
      </motion.div>
    </div>
  );
};

// ─── Status badge ─────────────────────────────────────────────
const statusConfig: Record<OrderStatus, { label: string; color: string }> = {
  pending:    { label: 'Ожидает',  color: 'text-yellow-400 border-yellow-400/30 bg-yellow-400/10' },
  confirmed:  { label: 'Подтверждён', color: 'text-blue-400 border-blue-400/30 bg-blue-400/10' },
  processing: { label: 'В обработке', color: 'text-purple-400 border-purple-400/30 bg-purple-400/10' },
  shipped:    { label: 'Отправлен', color: 'text-cyan-400 border-cyan-400/30 bg-cyan-400/10' },
  delivered:  { label: 'Доставлен', color: 'text-green-400 border-green-400/30 bg-green-400/10' },
  cancelled:  { label: 'Отменён',  color: 'text-red-400 border-red-400/30 bg-red-400/10' },
};

const StatusBadge = ({ status }: { status: OrderStatus }) => {
  const cfg = statusConfig[status] || statusConfig.pending;
  return (
    <span className={`font-mono text-[10px] tracking-wider border px-2 py-0.5 ${cfg.color}`}>
      {cfg.label}
    </span>
  );
};

// ─── Order card ───────────────────────────────────────────────
const OrderCard = ({ order, onStatusChange }: { order: Order; onStatusChange: () => void }) => {
  const [expanded, setExpanded] = useState(false);
  const [updating, setUpdating] = useState(false);

  const handleStatus = async (status: string) => {
    setUpdating(true);
    try {
      await updateOrderStatus(order.id, status);
      onStatusChange();
    } catch (e) {
      console.error(e);
    } finally {
      setUpdating(false);
    }
  };

  return (
    <motion.div layout className="card mb-3 overflow-hidden">
      <div
        className="p-4 flex items-start justify-between cursor-pointer"
        onClick={() => setExpanded(!expanded)}
      >
        <div>
          <p className="font-mono text-xs text-brand-gray-500 mb-1">
            #{order.order_number} · {new Date(order.created_at).toLocaleDateString('ru-RU')}
          </p>
          <p className="font-body font-medium text-brand-white">
            {order.first_name} {order.last_name}
          </p>
          <p className="font-mono text-sm text-brand-gray-400 mt-1">{formatPrice(order.total_amount)}</p>
        </div>
        <div className="flex items-center gap-2">
          <StatusBadge status={order.status} />
          <ChevronDown
            size={14}
            className={`text-brand-gray-500 transition-transform ${expanded ? 'rotate-180' : ''}`}
          />
        </div>
      </div>

      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0 }}
            animate={{ height: 'auto' }}
            exit={{ height: 0 }}
            className="overflow-hidden border-t border-brand-gray-800"
          >
            <div className="p-4 space-y-4">
              {/* Client info */}
              <div className="space-y-1">
                <p className="section-tag mb-2">КЛИЕНТ</p>
                <p className="font-body text-sm text-brand-gray-300">📞 {order.phone}</p>
                {order.telegram_username && (
                  <p className="font-body text-sm text-brand-gray-300">✈️ @{order.telegram_username}</p>
                )}
                <p className="font-body text-sm text-brand-gray-300">📍 {order.address}</p>
                {order.comment && (
                  <p className="font-body text-sm text-brand-gray-400 italic">💬 {order.comment}</p>
                )}
              </div>

              {/* Items */}
              {order.items?.length && (
                <div>
                  <p className="section-tag mb-2">ТОВАРЫ</p>
                  <div className="space-y-1">
                    {order.items.map(item => (
                      <div key={item.id} className="flex justify-between text-sm">
                        <span className="text-brand-gray-400 font-body">
                          {item.product_name} [{item.size}] × {item.quantity}
                        </span>
                        <span className="font-mono text-xs text-brand-white">
                          {formatPrice(item.price * item.quantity)}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Status change */}
              <div>
                <p className="section-tag mb-2">СТАТУС</p>
                <div className="grid grid-cols-3 gap-1.5">
                  {(Object.keys(statusConfig) as OrderStatus[]).map(s => (
                    <button
                      key={s}
                      disabled={updating || order.status === s}
                      onClick={() => handleStatus(s)}
                      className={`font-mono text-[9px] tracking-wider py-1.5 px-2 border transition-all
                        ${order.status === s
                          ? 'bg-brand-white text-brand-black border-brand-white'
                          : 'border-brand-gray-700 text-brand-gray-400 hover:border-brand-gray-400'
                        }
                        disabled:opacity-40`}
                    >
                      {statusConfig[s].label.toUpperCase()}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

// ─── Product form modal ───────────────────────────────────────
const ProductFormModal = ({
  product,
  onSave,
  onClose,
}: {
  product?: Product;
  onSave: () => void;
  onClose: () => void;
}) => {
  const [form, setForm] = useState({
    name: product?.name || '',
    description: product?.description || '',
    price: product?.price?.toString() || '',
    sizes: product?.sizes?.join(',') || 'XS,S,M,L,XL,XXL',
    is_active: product?.is_active ?? true,
  });
  const [files, setFiles] = useState<File[]>([]);
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    try {
      const payload = {
        name: form.name,
        description: form.description,
        price: Number(form.price),
        sizes: form.sizes.split(',').map(s => s.trim()),
        is_active: form.is_active,
      };

      if (product) {
        await updateProduct(product.id, payload);
        if (files.length) await uploadProductImages(product.id, files);
      } else {
        const created = await createProduct(payload);
        if (files.length) await uploadProductImages(created.id, files);
      }
      onSave();
      onClose();
    } catch (e) {
      console.error(e);
    } finally {
      setSaving(false);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-brand-black/90 backdrop-blur-sm flex items-end"
      onClick={onClose}
    >
      <motion.div
        initial={{ y: '100%' }}
        animate={{ y: 0 }}
        exit={{ y: '100%' }}
        transition={{ type: 'spring', damping: 30 }}
        className="w-full bg-brand-gray-900 border-t border-brand-gray-700 max-h-[90vh] overflow-y-auto"
        onClick={e => e.stopPropagation()}
      >
        <div className="p-4">
          <div className="flex items-center justify-between mb-6">
            <h2 className="display-text text-2xl">
              {product ? 'РЕДАКТИРОВАТЬ' : 'НОВЫЙ ТОВАР'}
            </h2>
            <button onClick={onClose}><X size={20} className="text-brand-gray-400" /></button>
          </div>

          <div className="space-y-3">
            <input
              value={form.name}
              onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
              placeholder="Название *"
              className="input-field"
            />
            <textarea
              value={form.description}
              onChange={e => setForm(f => ({ ...f, description: e.target.value }))}
              placeholder="Описание"
              rows={3}
              className="input-field resize-none"
            />
            <input
              value={form.price}
              onChange={e => setForm(f => ({ ...f, price: e.target.value }))}
              placeholder="Цена (сум) *"
              type="number"
              className="input-field"
            />
            <input
              value={form.sizes}
              onChange={e => setForm(f => ({ ...f, sizes: e.target.value }))}
              placeholder="Размеры (XS,S,M,L,XL)"
              className="input-field"
            />

            {/* Upload */}
            <div>
              <label className="block section-tag mb-2">ФОТО</label>
              <label className="flex items-center gap-2 border border-dashed border-brand-gray-700 p-4 cursor-pointer hover:border-brand-gray-500 transition-colors">
                <Upload size={16} className="text-brand-gray-500" />
                <span className="font-mono text-xs text-brand-gray-500">
                  {files.length ? `${files.length} файл(ов)` : 'Загрузить фото'}
                </span>
                <input
                  type="file"
                  multiple
                  accept="image/*"
                  className="hidden"
                  onChange={e => setFiles(Array.from(e.target.files || []))}
                />
              </label>
            </div>

            <div className="flex items-center gap-3">
              <button
                onClick={() => setForm(f => ({ ...f, is_active: !f.is_active }))}
                className={`w-10 h-5 rounded-full transition-colors ${form.is_active ? 'bg-brand-white' : 'bg-brand-gray-700'}`}
              >
                <div className={`w-4 h-4 rounded-full bg-brand-black mx-0.5 transition-transform ${form.is_active ? 'translate-x-5' : 'translate-x-0'}`} />
              </button>
              <span className="font-mono text-xs text-brand-gray-400">
                {form.is_active ? 'Активен' : 'Скрыт'}
              </span>
            </div>
          </div>

          <div className="flex gap-3 mt-6">
            <button onClick={onClose} className="btn-outline flex-1">ОТМЕНА</button>
            <button onClick={handleSave} disabled={saving} className="btn-primary flex-1">
              {saving ? 'СОХРАНЕНИЕ...' : 'СОХРАНИТЬ'}
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
};

// ─── Main admin panel ─────────────────────────────────────────
export const AdminPage = () => {
  const { isAuthenticated, username, logout } = useAdminStore();
  const [tab, setTab] = useState<'orders' | 'products'>('orders');
  const [orders, setOrders] = useState<Order[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [productModal, setProductModal] = useState<{ open: boolean; product?: Product }>({ open: false });
  const [statusFilter, setStatusFilter] = useState('');

  if (!isAuthenticated) return <AdminLogin />;

  const loadOrders = async () => {
    try {
      const { orders } = await fetchOrders({ status: statusFilter || undefined });
      setOrders(orders);
    } catch (e) { console.error(e); }
  };

  const loadProducts = async () => {
    try {
      const data = await adminFetchProducts();
      setProducts(data);
    } catch (e) { console.error(e); }
  };

  useEffect(() => {
    setLoading(true);
    Promise.all([loadOrders(), loadProducts()]).finally(() => setLoading(false));
  }, [statusFilter]);

  const handleDeleteProduct = async (id: string) => {
    if (!confirm('Удалить товар?')) return;
    await deleteProduct(id);
    loadProducts();
  };

  return (
    <div className="min-h-screen bg-brand-black">
      {/* Admin header */}
      <div className="sticky top-0 z-40 bg-brand-black border-b border-brand-gray-800">
        <div className="flex items-center justify-between px-4 h-14">
          <div>
            <span className="display-text text-xl text-brand-white">ADMIN</span>
            <span className="font-mono text-xs text-brand-gray-500 ml-2">{username}</span>
          </div>
          <button
            onClick={logout}
            className="flex items-center gap-1.5 text-brand-gray-400 hover:text-red-400 transition-colors"
          >
            <LogOut size={16} strokeWidth={1.5} />
            <span className="font-mono text-xs">ВЫЙТИ</span>
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-t border-brand-gray-800">
          {[
            { key: 'orders', label: 'ЗАКАЗЫ', icon: ShoppingBag },
            { key: 'products', label: 'ТОВАРЫ', icon: Package },
          ].map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              onClick={() => setTab(key as 'orders' | 'products')}
              className={`flex-1 flex items-center justify-center gap-2 py-3 font-mono text-xs tracking-widest transition-colors border-b-2
                ${tab === key ? 'text-brand-white border-brand-white' : 'text-brand-gray-500 border-transparent'}`}
            >
              <Icon size={14} strokeWidth={1.5} />
              {label}
            </button>
          ))}
        </div>
      </div>

      <div className="px-4 py-4">
        {/* ── Orders tab ── */}
        {tab === 'orders' && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="section-tag">{orders.length} ЗАКАЗОВ</span>
              <button onClick={loadOrders} className="p-1.5 text-brand-gray-500 hover:text-brand-white">
                <RefreshCw size={14} />
              </button>
            </div>

            {/* Status filter */}
            <div className="flex gap-1.5 overflow-x-auto no-scrollbar mb-4">
              {['', 'pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled'].map(s => (
                <button
                  key={s}
                  onClick={() => setStatusFilter(s)}
                  className={`flex-shrink-0 font-mono text-[10px] tracking-wider px-2.5 py-1 border transition-all
                    ${statusFilter === s
                      ? 'bg-brand-white text-brand-black border-brand-white'
                      : 'border-brand-gray-700 text-brand-gray-500 hover:border-brand-gray-500'
                    }`}
                >
                  {s ? statusConfig[s as OrderStatus]?.label.toUpperCase() : 'ВСЕ'}
                </button>
              ))}
            </div>

            {loading ? (
              <div className="text-center py-12 text-brand-gray-600 font-mono text-xs">ЗАГРУЗКА...</div>
            ) : orders.length === 0 ? (
              <div className="text-center py-12 text-brand-gray-600 font-mono text-xs">ЗАКАЗОВ НЕТ</div>
            ) : (
              orders.map(order => (
                <OrderCard key={order.id} order={order} onStatusChange={loadOrders} />
              ))
            )}
          </div>
        )}

        {/* ── Products tab ── */}
        {tab === 'products' && (
          <div>
            <div className="flex items-center justify-between mb-4">
              <span className="section-tag">{products.length} ТОВАРОВ</span>
              <button
                onClick={() => setProductModal({ open: true })}
                className="flex items-center gap-1.5 font-mono text-xs text-brand-white border border-brand-gray-700 px-3 py-1.5 hover:border-brand-white transition-colors"
              >
                <Plus size={12} />
                ДОБАВИТЬ
              </button>
            </div>

            <div className="space-y-2">
              {products.map(product => (
                <motion.div
                  key={product.id}
                  layout
                  className="card flex items-center gap-3 p-3"
                >
                  {product.images?.[0] && (
                    <img
                      src={product.images[0].url}
                      alt={product.name}
                      className="w-12 h-14 object-cover flex-shrink-0 bg-brand-gray-800"
                    />
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="font-body font-medium text-sm text-brand-white truncate">
                      {product.name}
                    </p>
                    <p className="font-mono text-xs text-brand-gray-400 mt-0.5">
                      {formatPrice(product.price)}
                    </p>
                    <div className="flex items-center gap-2 mt-1">
                      <span className={`font-mono text-[9px] ${product.is_active ? 'text-green-400' : 'text-brand-gray-600'}`}>
                        {product.is_active ? '● ACTIVE' : '● HIDDEN'}
                      </span>
                      <span className="font-mono text-[9px] text-brand-gray-600">
                        {product.sizes?.join(' ')}
                      </span>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <button
                      onClick={() => setProductModal({ open: true, product })}
                      className="p-2 text-brand-gray-500 hover:text-brand-white transition-colors"
                    >
                      <Edit2 size={14} strokeWidth={1.5} />
                    </button>
                    <button
                      onClick={() => handleDeleteProduct(product.id)}
                      className="p-2 text-brand-gray-500 hover:text-red-400 transition-colors"
                    >
                      <Trash2 size={14} strokeWidth={1.5} />
                    </button>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Product modal */}
      <AnimatePresence>
        {productModal.open && (
          <ProductFormModal
            product={productModal.product}
            onSave={() => { loadProducts(); }}
            onClose={() => setProductModal({ open: false })}
          />
        )}
      </AnimatePresence>
    </div>
  );
};
