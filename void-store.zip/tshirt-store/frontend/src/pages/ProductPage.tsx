import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { ArrowLeft, ShoppingBag, ChevronLeft, ChevronRight } from 'lucide-react';
import { fetchProduct } from '../utils/api';
import { Product } from '../types';
import { formatPrice, getImageUrl } from '../utils/helpers';
import { useCartStore } from '../store/cartStore';
import { SizeSelector } from '../components/product/SizeSelector';
import { QuantityPicker } from '../components/ui/QuantityPicker';
import { PageLoader } from '../components/ui/Spinner';
import { haptic } from '../hooks/useTelegram';
import toast from 'react-hot-toast';

export const ProductPage = () => {
  const { slug } = useParams<{ slug: string }>();
  const navigate = useNavigate();
  const addItem = useCartStore(s => s.addItem);

  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedSize, setSelectedSize] = useState<string | null>(null);
  const [quantity, setQuantity] = useState(1);
  const [imageIndex, setImageIndex] = useState(0);
  const [sizeError, setSizeError] = useState(false);

  useEffect(() => {
    if (!slug) return;
    fetchProduct(slug)
      .then(p => { setProduct(p); setLoading(false); })
      .catch(() => { navigate('/'); });
  }, [slug]);

  if (loading) return <PageLoader />;
  if (!product) return null;

  const images = product.images?.length
    ? product.images.sort((a, b) => a.sort_order - b.sort_order)
    : [{ url: getImageUrl(), id: '0', product_id: '0', is_primary: true, sort_order: 0 }];

  const handleAddToCart = () => {
    if (!selectedSize) {
      setSizeError(true);
      haptic.error();
      setTimeout(() => setSizeError(false), 800);
      return;
    }
    addItem(product, selectedSize, quantity);
    haptic.success();
    toast.success('Добавлено в корзину', {
      style: {
        background: '#F5F5F0',
        color: '#0A0A0A',
        fontFamily: '"DM Sans", sans-serif',
        fontSize: '13px',
        letterSpacing: '0.05em',
      },
    });
  };

  return (
    <div className="min-h-screen pb-32">
      {/* Back button */}
      <div className="fixed top-14 left-0 right-0 z-40 bg-brand-black/80 backdrop-blur-sm">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 px-4 py-3 text-brand-gray-400 hover:text-brand-white transition-colors"
        >
          <ArrowLeft size={16} strokeWidth={1.5} />
          <span className="font-mono text-xs tracking-widest">НАЗАД</span>
        </button>
      </div>

      {/* Image gallery */}
      <div className="relative pt-[104px]">
        <div className="relative overflow-hidden bg-brand-gray-900 aspect-square">
          <AnimatePresence mode="wait">
            <motion.img
              key={imageIndex}
              src={images[imageIndex].url}
              alt={product.name}
              className="w-full h-full object-cover"
              initial={{ opacity: 0, scale: 1.03 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.97 }}
              transition={{ duration: 0.3 }}
            />
          </AnimatePresence>

          {/* Image nav arrows */}
          {images.length > 1 && (
            <>
              <button
                onClick={() => setImageIndex(i => (i - 1 + images.length) % images.length)}
                className="absolute left-2 top-1/2 -translate-y-1/2 w-9 h-9 bg-brand-black/60 flex items-center justify-center"
              >
                <ChevronLeft size={18} />
              </button>
              <button
                onClick={() => setImageIndex(i => (i + 1) % images.length)}
                className="absolute right-2 top-1/2 -translate-y-1/2 w-9 h-9 bg-brand-black/60 flex items-center justify-center"
              >
                <ChevronRight size={18} />
              </button>
            </>
          )}

          {/* Dots */}
          {images.length > 1 && (
            <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
              {images.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setImageIndex(i)}
                  className={`w-1.5 h-1.5 rounded-full transition-all duration-200 ${i === imageIndex ? 'bg-brand-white w-4' : 'bg-brand-gray-600'}`}
                />
              ))}
            </div>
          )}
        </div>

        {/* Thumbnails */}
        {images.length > 1 && (
          <div className="flex gap-2 px-4 mt-3 overflow-x-auto no-scrollbar">
            {images.map((img, i) => (
              <button
                key={img.id}
                onClick={() => setImageIndex(i)}
                className={`flex-shrink-0 w-16 h-16 overflow-hidden border transition-all duration-200 ${
                  i === imageIndex ? 'border-brand-white' : 'border-brand-gray-800 opacity-50'
                }`}
              >
                <img src={img.url} alt="" className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Product info */}
      <div className="px-4 mt-6 space-y-6">
        {/* Name & price */}
        <div>
          <p className="section-tag mb-2">{product.category_name || 'TSHIRT'}</p>
          <h1 className="display-text text-4xl text-brand-white mb-3">{product.name}</h1>
          <p className="font-mono text-xl text-brand-white">{formatPrice(product.price)}</p>
        </div>

        {/* Description */}
        {product.description && (
          <div className="border-t border-brand-gray-800 pt-4">
            <p className="section-tag mb-2">ОПИСАНИЕ</p>
            <p className="font-body text-sm text-brand-gray-400 leading-relaxed">
              {product.description}
            </p>
          </div>
        )}

        {/* Size selector */}
        <div className={`border-t border-brand-gray-800 pt-4 ${sizeError ? 'animate-pulse' : ''}`}>
          {sizeError && (
            <p className="font-mono text-xs text-red-400 mb-2">← Выберите размер</p>
          )}
          <SizeSelector
            sizes={product.sizes}
            selected={selectedSize}
            onSelect={setSelectedSize}
          />
        </div>

        {/* Quantity */}
        <div className="border-t border-brand-gray-800 pt-4">
          <p className="section-tag mb-3">КОЛИЧЕСТВО</p>
          <QuantityPicker value={quantity} onChange={setQuantity} />
        </div>

        {/* Specs */}
        <div className="border-t border-brand-gray-800 pt-4 grid grid-cols-2 gap-3">
          {[
            ['Материал', '100% Cotton'],
            ['Плотность', '300gsm'],
            ['Крой', 'Oversized'],
            ['Уход', 'Machine wash 30°'],
          ].map(([k, v]) => (
            <div key={k}>
              <p className="section-tag text-[9px] mb-1">{k}</p>
              <p className="font-body text-xs text-brand-gray-300">{v}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Fixed bottom CTA */}
      <div className="fixed bottom-0 left-0 right-0 bg-brand-black border-t border-brand-gray-800 p-4">
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={handleAddToCart}
          className="btn-primary w-full flex items-center justify-center gap-3"
        >
          <ShoppingBag size={16} strokeWidth={1.5} />
          <span className="tracking-widest">ДОБАВИТЬ В КОРЗИНУ</span>
          <span className="font-mono text-sm opacity-70">
            {formatPrice(product.price * quantity)}
          </span>
        </motion.button>
      </div>
    </div>
  );
};
