import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { ArrowLeft, CheckCircle2 } from 'lucide-react';
import { useCartStore } from '../store/cartStore';
import { createOrder } from '../utils/api';
import { formatPrice } from '../utils/helpers';
import { useTelegram, haptic } from '../hooks/useTelegram';
import toast from 'react-hot-toast';

const schema = z.object({
  first_name: z.string().min(2, 'Введите имя'),
  last_name: z.string().min(2, 'Введите фамилию'),
  phone: z.string().min(9, 'Введите корректный номер'),
  telegram_username: z.string().optional(),
  address: z.string().min(10, 'Введите полный адрес'),
  comment: z.string().optional(),
});

type FormData = z.infer<typeof schema>;

export const CheckoutPage = () => {
  const navigate = useNavigate();
  const { items, clearCart, totalAmount } = useCartStore();
  const { user } = useTelegram();
  const [submitting, setSubmitting] = useState(false);
  const [success, setSuccess] = useState<{ order_number: number } | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: {
      first_name: user?.first_name || '',
      last_name: user?.last_name || '',
      telegram_username: user?.username || '',
    },
  });

  if (!items.length && !success) {
    navigate('/cart');
    return null;
  }

  const onSubmit = async (data: FormData) => {
    setSubmitting(true);
    try {
      const result = await createOrder({
        ...data,
        telegram_user_id: user?.id,
        items: items.map(i => ({
          product_id: i.product.id,
          size: i.size,
          quantity: i.quantity,
        })),
      });
      setSuccess({ order_number: result.order_number });
      clearCart();
      haptic.success();
    } catch {
      toast.error('Ошибка при оформлении заказа', {
        style: { background: '#1a1a1a', color: '#F5F5F0', fontSize: '13px' },
      });
      haptic.error();
    } finally {
      setSubmitting(false);
    }
  };

  // ─── Success screen ─────────────────────────────────────────
  if (success) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-4 pt-14">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ type: 'spring', bounce: 0.3 }}
          className="text-center"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, type: 'spring', bounce: 0.5 }}
          >
            <CheckCircle2 size={64} strokeWidth={1} className="text-brand-white mx-auto mb-6" />
          </motion.div>
          <p className="section-tag mb-2">ЗАКАЗ ОФОРМЛЕН</p>
          <h2 className="display-text text-5xl text-brand-white mb-4">
            #{success.order_number}
          </h2>
          <p className="font-body text-sm text-brand-gray-400 mb-8 max-w-xs mx-auto leading-relaxed">
            Мы получили ваш заказ и свяжемся с вами в ближайшее время для подтверждения.
          </p>
          <button
            onClick={() => navigate('/')}
            className="btn-primary"
          >
            <span className="tracking-widest">В МАГАЗИН</span>
          </button>
        </motion.div>
      </div>
    );
  }

  // ─── Checkout form ───────────────────────────────────────────
  return (
    <div className="min-h-screen pt-14 pb-36">
      <div className="px-4 py-6">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-brand-gray-400 hover:text-brand-white transition-colors mb-6"
        >
          <ArrowLeft size={16} strokeWidth={1.5} />
          <span className="font-mono text-xs tracking-widest">КОРЗИНА</span>
        </button>

        <h1 className="display-text text-4xl mb-8">ОФОРМЛЕНИЕ</h1>

        {/* Order summary */}
        <div className="card p-4 mb-8">
          <p className="section-tag mb-3">ВАШ ЗАКАЗ</p>
          <div className="space-y-2 mb-3">
            {items.map(item => (
              <div key={`${item.product.id}-${item.size}`} className="flex justify-between text-sm">
                <span className="text-brand-gray-400 font-body">
                  {item.product.name} [{item.size}] × {item.quantity}
                </span>
                <span className="font-mono text-brand-white text-xs">
                  {formatPrice(item.product.price * item.quantity)}
                </span>
              </div>
            ))}
          </div>
          <div className="border-t border-brand-gray-700 pt-2 flex justify-between">
            <span className="section-tag">ИТОГО</span>
            <span className="font-mono text-brand-white">{formatPrice(totalAmount())}</span>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
          <p className="section-tag mb-1">ВАШИ ДАННЫЕ</p>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <input
                {...register('first_name')}
                placeholder="Имя"
                className="input-field"
              />
              {errors.first_name && (
                <p className="text-red-400 text-[11px] mt-1 font-mono">{errors.first_name.message}</p>
              )}
            </div>
            <div>
              <input
                {...register('last_name')}
                placeholder="Фамилия"
                className="input-field"
              />
              {errors.last_name && (
                <p className="text-red-400 text-[11px] mt-1 font-mono">{errors.last_name.message}</p>
              )}
            </div>
          </div>

          <div>
            <input
              {...register('phone')}
              placeholder="+998 XX XXX XX XX"
              type="tel"
              className="input-field"
            />
            {errors.phone && (
              <p className="text-red-400 text-[11px] mt-1 font-mono">{errors.phone.message}</p>
            )}
          </div>

          <div>
            <input
              {...register('telegram_username')}
              placeholder="@username (Telegram)"
              className="input-field"
            />
          </div>

          <div className="pt-2">
            <p className="section-tag mb-3">ДОСТАВКА</p>
            <textarea
              {...register('address')}
              placeholder="Город, улица, дом, квартира..."
              rows={3}
              className="input-field resize-none"
            />
            {errors.address && (
              <p className="text-red-400 text-[11px] mt-1 font-mono">{errors.address.message}</p>
            )}
          </div>

          <div>
            <textarea
              {...register('comment')}
              placeholder="Комментарий к заказу (необязательно)"
              rows={2}
              className="input-field resize-none"
            />
          </div>
        </form>
      </div>

      {/* Fixed submit */}
      <div className="fixed bottom-0 left-0 right-0 bg-brand-black border-t border-brand-gray-800 p-4">
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={handleSubmit(onSubmit)}
          disabled={submitting}
          className="btn-primary w-full flex items-center justify-center gap-2"
        >
          {submitting ? (
            <span className="tracking-widest">ОФОРМЛЯЕМ...</span>
          ) : (
            <>
              <span className="tracking-widest">ОФОРМИТЬ ЗАКАЗ</span>
              <span className="font-mono text-sm opacity-60">{formatPrice(totalAmount())}</span>
            </>
          )}
        </motion.button>
      </div>
    </div>
  );
};
