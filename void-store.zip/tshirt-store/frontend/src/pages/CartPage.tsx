import { Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Trash2, ArrowLeft, ArrowRight, ShoppingBag } from 'lucide-react';
import { useCartStore } from '../store/cartStore';
import { QuantityPicker } from '../components/ui/QuantityPicker';
import { formatPrice, getImageUrl } from '../utils/helpers';
import { haptic } from '../hooks/useTelegram';

export const CartPage = () => {
  const { items, removeItem, updateQuantity, totalAmount } = useCartStore();
  const navigate = useNavigate();

  if (!items.length) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center px-4 pt-14">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <ShoppingBag
            size={64}
            strokeWidth={0.8}
            className="text-brand-gray-700 mx-auto mb-6"
          />
          <h2 className="display-text text-3xl text-brand-gray-600 mb-2">КОРЗИНА ПУСТА</h2>
          <p className="font-body text-sm text-brand-gray-500 mb-8">
            Добавьте что-нибудь из каталога
          </p>
          <Link to="/" className="btn-outline inline-flex items-center gap-2">
            <span className="tracking-widest">В КАТАЛОГ</span>
            <ArrowRight size={14} />
          </Link>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-14 pb-36">
      <div className="px-4 py-6">
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 text-brand-gray-400 hover:text-brand-white transition-colors mb-6"
        >
          <ArrowLeft size={16} strokeWidth={1.5} />
          <span className="font-mono text-xs tracking-widest">НАЗАД</span>
        </button>

        <div className="flex items-baseline justify-between mb-6">
          <h1 className="display-text text-4xl">КОРЗИНА</h1>
          <span className="section-tag">{items.length} ТОВ.</span>
        </div>

        {/* Cart items */}
        <div className="space-y-0">
          <AnimatePresence>
            {items.map((item) => (
              <motion.div
                key={`${item.product.id}-${item.size}`}
                layout
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 20, height: 0 }}
                transition={{ duration: 0.2 }}
                className="flex gap-3 py-4 border-b border-brand-gray-800"
              >
                {/* Image */}
                <Link to={`/product/${item.product.slug}`} className="flex-shrink-0">
                  <div className="w-20 h-24 bg-brand-gray-900 overflow-hidden">
                    <img
                      src={getImageUrl(item.product.images)}
                      alt={item.product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                </Link>

                {/* Info */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <div>
                      <p className="section-tag mb-0.5">{item.product.category_name}</p>
                      <h3 className="font-display text-base tracking-wider leading-tight">
                        {item.product.name}
                      </h3>
                    </div>
                    <button
                      onClick={() => { removeItem(item.product.id, item.size); haptic.medium(); }}
                      className="p-1 text-brand-gray-600 hover:text-red-400 transition-colors flex-shrink-0"
                    >
                      <Trash2 size={14} strokeWidth={1.5} />
                    </button>
                  </div>

                  <div className="flex items-center gap-2 mb-3">
                    <span className="font-mono text-xs text-brand-gray-500 border border-brand-gray-700 px-2 py-0.5">
                      {item.size}
                    </span>
                  </div>

                  <div className="flex items-center justify-between">
                    <QuantityPicker
                      value={item.quantity}
                      onChange={q => updateQuantity(item.product.id, item.size, q)}
                    />
                    <span className="font-mono text-sm text-brand-white">
                      {formatPrice(item.product.price * item.quantity)}
                    </span>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </div>

      {/* Fixed bottom total + checkout */}
      <div className="fixed bottom-0 left-0 right-0 bg-brand-black border-t border-brand-gray-800 p-4 space-y-3">
        <div className="flex items-center justify-between">
          <span className="section-tag">ИТОГО</span>
          <span className="font-mono text-lg text-brand-white font-medium">
            {formatPrice(totalAmount())}
          </span>
        </div>
        <motion.button
          whileTap={{ scale: 0.97 }}
          onClick={() => { navigate('/checkout'); haptic.medium(); }}
          className="btn-primary w-full flex items-center justify-center gap-2"
        >
          <span className="tracking-widest">ОФОРМИТЬ ЗАКАЗ</span>
          <ArrowRight size={14} />
        </motion.button>
      </div>
    </div>
  );
};
