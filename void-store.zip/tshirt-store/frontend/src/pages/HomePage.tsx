import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { ProductCard } from '../components/product/ProductCard';
import { PageLoader } from '../components/ui/Spinner';
import { fetchProducts } from '../utils/api';
import { Product } from '../types';

export const HomePage = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeCategory, setActiveCategory] = useState<string>('ALL');

  useEffect(() => {
    fetchProducts()
      .then(setProducts)
      .catch(console.error)
      .finally(() => setLoading(false));
  }, []);

  const categories = ['ALL', ...Array.from(new Set(products.map(p => p.category_name || 'OTHER')))];

  const filtered = activeCategory === 'ALL'
    ? products
    : products.filter(p => p.category_name === activeCategory);

  return (
    <div className="min-h-screen">
      {/* Hero Banner */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        className="relative overflow-hidden bg-brand-gray-900 mb-8"
      >
        <div className="px-4 pt-20 pb-8">
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="section-tag mb-3"
          >
            SS 2025 COLLECTION
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="display-text text-[13vw] leading-none text-brand-white mb-2"
          >
            VOID
          </motion.h1>
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="display-text text-[13vw] leading-none text-brand-gray-700 mb-6"
          >
            STORE
          </motion.h2>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5 }}
            className="font-body text-sm text-brand-gray-500 max-w-xs leading-relaxed"
          >
            Premium heavyweight cotton. Oversized silhouettes.
            Built for the streets, worn everywhere.
          </motion.p>
        </div>

        {/* Decorative line */}
        <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-brand-gray-700 to-transparent" />
      </motion.div>

      <div className="px-4">
        {/* Category filter */}
        <div className="flex gap-0 mb-8 overflow-x-auto no-scrollbar border-b border-brand-gray-800">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`
                flex-shrink-0 px-4 py-2.5 font-mono text-[10px] tracking-ultrawide transition-all duration-200 border-b-2 -mb-px
                ${activeCategory === cat
                  ? 'text-brand-white border-brand-white'
                  : 'text-brand-gray-500 border-transparent hover:text-brand-gray-300'
                }
              `}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Products grid */}
        {loading ? (
          <PageLoader />
        ) : (
          <>
            <div className="flex items-center justify-between mb-5">
              <span className="section-tag">{filtered.length} ПОЗИЦИЙ</span>
            </div>
            <div className="grid grid-cols-2 gap-4 pb-24">
              {filtered.map((product, i) => (
                <ProductCard key={product.id} product={product} index={i} />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
};
