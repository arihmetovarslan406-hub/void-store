export const formatPrice = (amount: number): string => {
  return new Intl.NumberFormat('uz-UZ').format(amount) + ' сум';
};

export const getImageUrl = (images?: { url: string; is_primary: boolean }[]): string => {
  if (!images?.length) return 'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?w=600';
  const primary = images.find(i => i.is_primary);
  return primary?.url || images[0].url;
};

export const clsx = (...classes: (string | undefined | null | false)[]): string => {
  return classes.filter(Boolean).join(' ');
};
