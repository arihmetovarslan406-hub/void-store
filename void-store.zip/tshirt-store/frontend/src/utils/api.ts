import axios from 'axios';
import { Product, Order } from '../types';

const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || '/api',
  timeout: 10000,
});

// ─── Products ─────────────────────────────────────────────────
export const fetchProducts = async (): Promise<Product[]> => {
  const { data } = await api.get<Product[]>('/products');
  return data;
};

export const fetchProduct = async (slug: string): Promise<Product> => {
  const { data } = await api.get<Product>(`/products/${slug}`);
  return data;
};

export const fetchCategories = async () => {
  const { data } = await api.get('/products/categories');
  return data;
};

// ─── Orders ───────────────────────────────────────────────────
export const createOrder = async (orderData: {
  first_name: string;
  last_name: string;
  phone: string;
  telegram_username?: string;
  telegram_user_id?: number;
  address: string;
  comment?: string;
  items: { product_id: string; size: string; quantity: number }[];
}) => {
  const { data } = await api.post('/orders', orderData);
  return data as { order_number: number; id: string };
};

// ─── Admin ────────────────────────────────────────────────────
export const adminLogin = async (username: string, password: string) => {
  const { data } = await api.post('/auth/login', { username, password });
  return data as { token: string; username: string };
};

export const fetchOrders = async (params?: {
  status?: string;
  page?: number;
  limit?: number;
}) => {
  const { data } = await api.get('/orders', { params });
  return data as { orders: Order[]; total: number };
};

export const updateOrderStatus = async (id: string, status: string) => {
  const { data } = await api.patch(`/orders/${id}/status`, { status });
  return data as Order;
};

export const adminFetchProducts = async (): Promise<Product[]> => {
  const { data } = await api.get<Product[]>('/products/admin/all');
  return data;
};

export const createProduct = async (productData: Partial<Product>) => {
  const { data } = await api.post('/products', productData);
  return data as Product;
};

export const updateProduct = async (id: string, productData: Partial<Product>) => {
  const { data } = await api.patch(`/products/${id}`, productData);
  return data as Product;
};

export const deleteProduct = async (id: string) => {
  await api.delete(`/products/${id}`);
};

export const uploadProductImages = async (id: string, files: File[]) => {
  const form = new FormData();
  files.forEach(f => form.append('images', f));
  const { data } = await api.post(`/products/${id}/images`, form, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return data;
};

export default api;
