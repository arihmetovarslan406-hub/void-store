import { useEffect, useState } from 'react';

interface TelegramUser {
  id: number;
  username?: string;
  first_name?: string;
  last_name?: string;
}

interface UseTelegram {
  tg: Window['Telegram']['WebApp'] | null;
  user: TelegramUser | null;
  isInTelegram: boolean;
}

export const useTelegram = (): UseTelegram => {
  const [tg, setTg] = useState<Window['Telegram']['WebApp'] | null>(null);
  const [user, setUser] = useState<TelegramUser | null>(null);

  useEffect(() => {
    const webapp = window.Telegram?.WebApp;
    if (webapp) {
      webapp.ready();
      webapp.expand();
      webapp.setBackgroundColor('#0A0A0A');
      webapp.setHeaderColor('#0A0A0A');
      setTg(webapp);
      setUser(webapp.initDataUnsafe?.user || null);
    }
  }, []);

  return {
    tg,
    user,
    isInTelegram: !!tg,
  };
};

export const haptic = {
  light: () => window.Telegram?.WebApp?.HapticFeedback?.impactOccurred('light'),
  medium: () => window.Telegram?.WebApp?.HapticFeedback?.impactOccurred('medium'),
  heavy: () => window.Telegram?.WebApp?.HapticFeedback?.impactOccurred('heavy'),
  success: () => window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred('success'),
  error: () => window.Telegram?.WebApp?.HapticFeedback?.notificationOccurred('error'),
  selection: () => window.Telegram?.WebApp?.HapticFeedback?.selectionChanged(),
};
