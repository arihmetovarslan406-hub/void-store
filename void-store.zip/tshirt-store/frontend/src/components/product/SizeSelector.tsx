import { motion } from 'framer-motion';
import { haptic } from '../../hooks/useTelegram';

interface SizeSelectorProps {
  sizes: string[];
  selected: string | null;
  onSelect: (size: string) => void;
}

export const SizeSelector = ({ sizes, selected, onSelect }: SizeSelectorProps) => {
  return (
    <div>
      <div className="flex items-center justify-between mb-3">
        <span className="section-tag">РАЗМЕР</span>
        {selected && (
          <span className="font-mono text-xs text-brand-white">{selected}</span>
        )}
      </div>
      <div className="flex gap-2 flex-wrap">
        {sizes.map(size => (
          <motion.button
            key={size}
            whileTap={{ scale: 0.92 }}
            onClick={() => { onSelect(size); haptic.selection(); }}
            className={`
              w-12 h-12 font-mono text-xs tracking-wider border transition-all duration-200
              ${selected === size
                ? 'bg-brand-white text-brand-black border-brand-white'
                : 'bg-transparent text-brand-gray-400 border-brand-gray-700 hover:border-brand-gray-400 hover:text-brand-white'
              }
            `}
          >
            {size}
          </motion.button>
        ))}
      </div>
    </div>
  );
};
