import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ShoppingBag, Plus } from 'lucide-react';
import { Product } from '../../types';
import { formatPrice, getImageUrl } from '../../utils/helpers';
import { useCartStore } from '../../store/cartStore';
import { haptic } from '../../hooks/useTelegram';
import toast from 'react-hot-toast';

interface ProductCardProps {
  product: Product;
  index?: number;
}

export const ProductCard = ({ product, index = 0 }: ProductCardProps) => {
  const addItem = useCartStore(s => s.addItem);
  const primaryImage = getImageUrl(product.images);

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const defaultSize = product.sizes[1] || product.sizes[0];
    if (!defaultSize) return;
    addItem(product, defaultSize);
    haptic.success();
    toast.success(`${product.name} добавлен`, {
      style: {
        background: '#F5F5F0',
        color: '#0A0A0A',
        fontFamily: '"DM Sans", sans-serif',
        fontSize: '13px',
        letterSpacing: '0.05em',
      },
    });
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4, delay: index * 0.08 }}
    >
      <Link to={`/product/${product.slug}`} className="block group">
        {/* Image */}
        <div className="relative overflow-hidden bg-brand-gray-900 aspect-[3/4] mb-3">
          <img
            src={primaryImage}
            alt={product.name}
            className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
            loading="lazy"
          />

          {/* Overlay on hover */}
          <div className="absolute inset-0 bg-brand-black/0 group-hover:bg-brand-black/20 transition-colors duration-300" />

          {/* Quick add button */}
          <motion.button
            onClick={handleQuickAdd}
            whileTap={{ scale: 0.9 }}
            className="absolute bottom-3 right-3 w-10 h-10 bg-brand-white text-brand-black
                       flex items-center justify-center
                       opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0
                       transition-all duration-300"
          >
            <Plus size={18} strokeWidth={2} />
          </motion.button>

          {/* Sizes preview */}
          <div className="absolute bottom-3 left-3 flex gap-1
                          opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0
                          transition-all duration-300">
            {product.sizes.slice(0, 4).map(size => (
              <span
                key={size}
                className="text-[9px] font-mono text-brand-white bg-brand-black/70 px-1.5 py-0.5"
              >
                {size}
              </span>
            ))}
          </div>
        </div>

        {/* Info */}
        <div className="px-0.5">
          <p className="section-tag mb-1">{product.category_name || 'TSHIRT'}</p>
          <h3 className="font-display text-lg tracking-wider text-brand-white group-hover:text-brand-gray-200 transition-colors leading-tight mb-1.5">
            {product.name}
          </h3>
          <p className="font-mono text-sm text-brand-gray-400">
            {formatPrice(product.price)}
          </p>
        </div>
      </Link>
    </motion.div>
  );
};
