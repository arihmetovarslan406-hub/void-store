import { motion } from 'framer-motion';

export const Spinner = ({ size = 24 }: { size?: number }) => (
  <motion.div
    animate={{ rotate: 360 }}
    transition={{ repeat: Infinity, duration: 1, ease: 'linear' }}
    className="border-2 border-brand-gray-700 border-t-brand-white rounded-full"
    style={{ width: size, height: size }}
  />
);

export const PageLoader = () => (
  <div className="flex items-center justify-center min-h-[60vh]">
    <div className="text-center">
      <Spinner size={32} />
      <p className="section-tag mt-4">ЗАГРУЗКА</p>
    </div>
  </div>
);
