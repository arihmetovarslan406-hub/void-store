import { Minus, Plus } from 'lucide-react';
import { motion } from 'framer-motion';
import { haptic } from '../../hooks/useTelegram';

interface QuantityPickerProps {
  value: number;
  onChange: (value: number) => void;
  min?: number;
  max?: number;
}

export const QuantityPicker = ({ value, onChange, min = 1, max = 99 }: QuantityPickerProps) => {
  const decrement = () => {
    if (value > min) { onChange(value - 1); haptic.light(); }
  };
  const increment = () => {
    if (value < max) { onChange(value + 1); haptic.light(); }
  };

  return (
    <div className="flex items-center border border-brand-gray-700">
      <motion.button
        whileTap={{ scale: 0.85 }}
        onClick={decrement}
        disabled={value <= min}
        className="w-11 h-11 flex items-center justify-center text-brand-gray-400 hover:text-brand-white disabled:opacity-30 transition-colors"
      >
        <Minus size={14} strokeWidth={2} />
      </motion.button>

      <span className="w-10 text-center font-mono text-sm text-brand-white">
        {value}
      </span>

      <motion.button
        whileTap={{ scale: 0.85 }}
        onClick={increment}
        disabled={value >= max}
        className="w-11 h-11 flex items-center justify-center text-brand-gray-400 hover:text-brand-white disabled:opacity-30 transition-colors"
      >
        <Plus size={14} strokeWidth={2} />
      </motion.button>
    </div>
  );
};
