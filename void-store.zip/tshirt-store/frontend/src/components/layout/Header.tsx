import { Link, useLocation } from 'react-router-dom';
import { ShoppingBag, Search, Menu } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useState } from 'react';
import { useCartStore } from '../../store/cartStore';
import { haptic } from '../../hooks/useTelegram';

export const Header = () => {
  const location = useLocation();
  const totalItems = useCartStore(s => s.totalItems());
  const [menuOpen, setMenuOpen] = useState(false);

  const isAdmin = location.pathname.startsWith('/admin');
  if (isAdmin) return null;

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-brand-black/95 backdrop-blur-sm border-b border-brand-gray-800">
      <div className="flex items-center justify-between px-4 h-14">
        {/* Logo */}
        <Link to="/" className="display-text text-2xl tracking-ultrawide text-brand-white">
          VOID
        </Link>

        {/* Right icons */}
        <div className="flex items-center gap-3">
          <Link
            to="/cart"
            className="relative p-2 text-brand-gray-400 hover:text-brand-white transition-colors"
            onClick={() => haptic.light()}
          >
            <ShoppingBag size={20} strokeWidth={1.5} />
            <AnimatePresence>
              {totalItems > 0 && (
                <motion.span
                  key="badge"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  exit={{ scale: 0 }}
                  className="absolute -top-0.5 -right-0.5 w-4 h-4 bg-brand-white text-brand-black text-[9px] font-mono font-medium flex items-center justify-center rounded-full"
                >
                  {totalItems > 9 ? '9+' : totalItems}
                </motion.span>
              )}
            </AnimatePresence>
          </Link>

          <button
            className="p-2 text-brand-gray-400 hover:text-brand-white transition-colors"
            onClick={() => { setMenuOpen(!menuOpen); haptic.light(); }}
          >
            <Menu size={20} strokeWidth={1.5} />
          </button>
        </div>
      </div>

      {/* Dropdown nav */}
      <AnimatePresence>
        {menuOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden border-t border-brand-gray-800 bg-brand-black"
          >
            <nav className="py-4 px-6 flex flex-col gap-1">
              {[
                { label: 'МАГАЗИН', to: '/' },
                { label: 'КОРЗИНА', to: '/cart' },
              ].map(({ label, to }) => (
                <Link
                  key={to}
                  to={to}
                  onClick={() => { setMenuOpen(false); haptic.selection(); }}
                  className="font-mono text-sm tracking-widest text-brand-gray-400 hover:text-brand-white transition-colors py-2"
                >
                  {label}
                </Link>
              ))}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
};
