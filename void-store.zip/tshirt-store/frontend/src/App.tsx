import { Routes, Route, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Toaster } from 'react-hot-toast';
import { Header } from './components/layout/Header';
import { HomePage } from './pages/HomePage';
import { ProductPage } from './pages/ProductPage';
import { CartPage } from './pages/CartPage';
import { CheckoutPage } from './pages/CheckoutPage';
import { AdminPage } from './pages/AdminPage';
import { useTelegram } from './hooks/useTelegram';
import { useEffect } from 'react';

const PageTransition = ({ children }: { children: React.ReactNode }) => (
  <motion.div
    initial={{ opacity: 0, y: 8 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: -8 }}
    transition={{ duration: 0.25 }}
  >
    {children}
  </motion.div>
);

function App() {
  const location = useLocation();
  const { tg } = useTelegram();

  useEffect(() => {
    // Lock scroll when in Telegram
    document.body.style.overflow = 'auto';
  }, []);

  return (
    <div className="max-w-lg mx-auto relative grain">
      <Header />
      <Toaster position="top-center" />
      <AnimatePresence mode="wait">
        <Routes location={location} key={location.pathname}>
          <Route path="/" element={<PageTransition><HomePage /></PageTransition>} />
          <Route path="/product/:slug" element={<PageTransition><ProductPage /></PageTransition>} />
          <Route path="/cart" element={<PageTransition><CartPage /></PageTransition>} />
          <Route path="/checkout" element={<PageTransition><CheckoutPage /></PageTransition>} />
          <Route path="/admin/*" element={<AdminPage />} />
        </Routes>
      </AnimatePresence>
    </div>
  );
}

export default App;
