/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      fontFamily: {
        display: ['"Bebas Neue"', 'Impact', 'sans-serif'],
        body: ['"DM Sans"', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      colors: {
        brand: {
          black: '#0A0A0A',
          white: '#F5F5F0',
          gray: {
            50:  '#F9F9F7',
            100: '#EFEFED',
            200: '#DCDCDA',
            300: '#BDBDBA',
            400: '#9C9C99',
            500: '#7A7A77',
            600: '#5E5E5B',
            700: '#3F3F3C',
            800: '#242422',
            900: '#141412',
          },
          accent: '#E8E0D4',
        },
      },
      letterSpacing: {
        widest: '0.25em',
        ultrawide: '0.4em',
      },
      animation: {
        'fade-up': 'fadeUp 0.5s ease forwards',
        'fade-in': 'fadeIn 0.3s ease forwards',
        'slide-right': 'slideRight 0.3s ease forwards',
      },
      keyframes: {
        fadeUp: {
          '0%': { opacity: '0', transform: 'translateY(20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideRight: {
          '0%': { transform: 'translateX(-100%)' },
          '100%': { transform: 'translateX(0)' },
        },
      },
    },
  },
  plugins: [],
};
